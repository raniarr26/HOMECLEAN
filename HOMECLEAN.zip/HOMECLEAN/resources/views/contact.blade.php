<div>
    <!-- The biggest battle is the war against ignorance. - Mustafa Kemal Atatürk -->
    selamat datang
</div>
