<!-- resources/views/list_barang.blade.php -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List Barang</title>
</head>
<body>
    <div>
        <h1>List Barang</h1>
        <p>Kode Barang: {{$id}}</p>
        <p>Nama Barang: {{$nama}}</p>
    </div>
</body>
</html>
