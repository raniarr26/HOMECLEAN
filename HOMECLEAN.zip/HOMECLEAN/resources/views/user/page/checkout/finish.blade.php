@extends('user.layout.index')

@section('content')
<div class="container mt-5">
    <h2>Pembayaran Berhasil</h2>
    <p>Terima kasih atas pembayaran Anda. Transaksi Anda berhasil diproses.</p>
</div>
@endsection
