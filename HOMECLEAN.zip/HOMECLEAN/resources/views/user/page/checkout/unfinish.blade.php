@extends('user.layout.index')

@section('content')
<div class="container mt-5">
    <h2>Pembayaran Belum Selesai</h2>
    <p>Transaksi Anda belum selesai. Silakan coba lagi.</p>
</div>
@endsection
