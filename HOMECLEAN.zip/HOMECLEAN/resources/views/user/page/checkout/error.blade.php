@extends('user.layout.index')

@section('content')
<div class="container mt-5">
    <h2>Pembayaran Gagal</h2>
    <p>Terjadi kesalahan dalam memproses pembayaran Anda. Silakan coba lagi.</p>
</div>
@endsection
