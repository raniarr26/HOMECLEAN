<?php

use Illuminate\Support\Facades\Auth;

// Routes untuk autentikasi (login, register, dll)

